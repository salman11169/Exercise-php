<?php
   $db_name = 'mysql:host=localhost;dbname=exercise;charset=utf8';
   $db_user_name = 'root';
   $db_user_pass = '';

   $conn = new PDO($db_name, $db_user_name, $db_user_pass);
